﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
namespace miniCalc
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
        private void btnPlus_Clicked(object sender, EventArgs e)
        {
            float rez = float.Parse(tbA.Text) + float.Parse(tbB.Text);
            lblResult.Text = "A + B = " + tbA.Text + " + " + tbB.Text + " = " +
           rez.ToString();
        }
        private void btnMinus_Clicked(object sender, EventArgs e)
        {
            float rez = float.Parse(tbA.Text) - float.Parse(tbB.Text);
            lblResult.Text = "A - B = " + tbA.Text + " - " + tbB.Text + " = " +
           rez.ToString();
        }
        private void btnMult_Clicked(object sender, EventArgs e)
        {
            float rez = float.Parse(tbA.Text) * float.Parse(tbB.Text);
            lblResult.Text = "A * B = " + tbA.Text + " * " + tbB.Text + " = " +
           rez.ToString();
        }
        private void btnDiv_Clicked(object sender, EventArgs e)
        {
            if (float.Parse(tbB.Text) != 0)
            {
                float rez = float.Parse(tbA.Text) / float.Parse(tbB.Text);
                lblResult.Text = "A / B = " + tbA.Text + " / " + tbB.Text + " = " +
               rez.ToString();
            }
            else
                lblResult.Text = "Невъзможно e деление на нула!";
        }
        private void btnClear_Clicked(object sender, EventArgs e)
        {
            lblResult.Text = "";
            tbA.Text = "";
            tbB.Text = "";
        }
    }
}